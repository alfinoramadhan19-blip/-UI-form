package com.example.formbiodata

import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etNama: EditText
    private lateinit var etNis: EditText
    private lateinit var etKelas: EditText
    private lateinit var etEmail: EditText
    private lateinit var etAlamat: EditText

    private lateinit var tvErrorNama: TextView
    private lateinit var tvErrorNis: TextView
    private lateinit var tvErrorKelas: TextView
    private lateinit var tvErrorEmail: TextView
    private lateinit var tvErrorAlamat: TextView

    private lateinit var btnSimpan: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etNama = findViewById(R.id.etNama)
        etNis = findViewById(R.id.etNis)
        etKelas = findViewById(R.id.etKelas)
        etEmail = findViewById(R.id.etEmail)
        etAlamat = findViewById(R.id.etAlamat)

        tvErrorNama = findViewById(R.id.tvErrorNama)
        tvErrorNis = findViewById(R.id.tvErrorNis)
        tvErrorKelas = findViewById(R.id.tvErrorKelas)
        tvErrorEmail = findViewById(R.id.tvErrorEmail)
        tvErrorAlamat = findViewById(R.id.tvErrorAlamat)

        btnSimpan = findViewById(R.id.btnSimpan)

        btnSimpan.setOnClickListener {
            if (validateForm()) {
                simpanData()
            } else {
                Toast.makeText(this, "Periksa kembali data yang belum lengkap", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun validateForm(): Boolean {
        var valid = true

        val nama = etNama.text.toString().trim()
        val nis = etNis.text.toString().trim()
        val kelas = etKelas.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val alamat = etAlamat.text.toString().trim()

        if (nama.isEmpty()) {
            showFieldError(etNama, tvErrorNama, true)
            valid = false
        } else {
            showFieldError(etNama, tvErrorNama, false)
        }

        if (nis.isEmpty() || !nis.all { it.isDigit() }) {
            showFieldError(etNis, tvErrorNis, true)
            valid = false
        } else {
            showFieldError(etNis, tvErrorNis, false)
        }

        if (kelas.isEmpty()) {
            showFieldError(etKelas, tvErrorKelas, true)
            valid = false
        } else {
            showFieldError(etKelas, tvErrorKelas, false)
        }

        if (email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showFieldError(etEmail, tvErrorEmail, true)
            valid = false
        } else {
            showFieldError(etEmail, tvErrorEmail, false)
        }

        if (alamat.isEmpty()) {
            showFieldError(etAlamat, tvErrorAlamat, true)
            valid = false
        } else {
            showFieldError(etAlamat, tvErrorAlamat, false)
        }

        return valid
    }

    private fun showFieldError(input: EditText, errorLabel: TextView, hasError: Boolean) {
        input.setBackgroundResource(
            if (hasError) R.drawable.bg_field_error else R.drawable.bg_field
        )
        errorLabel.visibility = if (hasError) TextView.VISIBLE else TextView.GONE
    }

    private fun simpanData() {
        val nama = etNama.text.toString().trim()
        val nis = etNis.text.toString().trim()
        val kelas = etKelas.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val alamat = etAlamat.text.toString().trim()

        // TODO: ganti bagian ini dengan penyimpanan ke database/Room/API sungguhan
        val ringkasan = "Nama: $nama\nNIS: $nis\nKelas: $kelas\nEmail: $email\nAlamat: $alamat"
        android.util.Log.d("FormBiodata", ringkasan)

        Toast.makeText(this, getString(R.string.toast_success), Toast.LENGTH_SHORT).show()

        etNama.text.clear()
        etNis.text.clear()
        etKelas.text.clear()
        etEmail.text.clear()
        etAlamat.text.clear()
    }
}
