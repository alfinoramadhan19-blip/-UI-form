# Form Biodata — Android Studio Project

Project Android Studio (Kotlin + XML Layout) untuk tugas "Form Biodata" — Pertemuan 5, Pemrograman Perangkat Bergerak.

## Cara membuka project

1. Ekstrak file zip ini.
2. Buka **Android Studio** → `File > Open` → pilih folder hasil ekstrak (folder yang berisi `settings.gradle`).
3. Tunggu proses **Gradle Sync** selesai (butuh koneksi internet saat pertama kali, untuk mengunduh dependency).
4. Jalankan lewat tombol **Run ▶** ke Emulator atau perangkat fisik.

## Struktur penting

- `app/src/main/res/layout/activity_main.xml` — UI Form Biodata (Nama, NIS, Kelas, Email, Alamat, tombol SIMPAN).
- `app/src/main/java/com/example/formbiodata/MainActivity.kt` — logika validasi input & aksi tombol SIMPAN.
- `app/src/main/res/values/strings.xml` — semua teks (label, hint, pesan error).
- `app/src/main/res/values/colors.xml` — palet warna.
- `app/src/main/res/drawable/` — background kartu, input field, dan tombol.

## Catatan

- Validasi sederhana sudah dibuat: Nama, NIS (angka), Kelas, Email (format valid), dan Alamat wajib diisi.
- Data yang disimpan saat ini hanya ditampilkan lewat Toast + Logcat (`simpanData()` di `MainActivity.kt`). Silakan sambungkan ke database (Room) atau API jika dibutuhkan.
- Untuk menambah komponen Spinner (Kelas) atau RadioGroup (Jenis Kelamin) sesuai tantangan di materi, tinggal tambahkan ke `activity_main.xml` dan ambil nilainya di `MainActivity.kt`.
